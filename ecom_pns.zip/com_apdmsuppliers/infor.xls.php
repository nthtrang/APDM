				
<html xmlns:v="urn:schemas-microsoft-com:vml"
xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:x="urn:schemas-microsoft-com:office:excel"
xmlns="http://www.w3.org/TR/REC-html40">
				

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=ProgId content=Excel.Sheet>
<meta name=Generator content="Microsoft Excel 11">
<!--[if !mso]>
<style>
v\:* {behavior:url(#default#VML);}
o\:* {behavior:url(#default#VML);}
x\:* {behavior:url(#default#VML);}
.shape {behavior:url(#default#VML);}
</style>
<![endif]--><!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:LastAuthor>hoang.pham</o:LastAuthor>
  <o:LastSaved>2008-11-21T07:34:41Z</o:LastSaved>
  <o:Version>11.5606</o:Version>
 </o:DocumentProperties>
 <o:OfficeDocumentSettings>
  <o:DownloadComponents/>
  <o:LocationOfComponents HRef="file:///S:\2-Microsoft%20Office\MS%20OFFICE%202003\"/>
 </o:OfficeDocumentSettings>
</xml><![endif]-->
<style>
<!--table
	{mso-displayed-decimal-separator:"\.";
	mso-displayed-thousand-separator:"\,";}
@page
	{margin:1.0in .75in 1.0in .75in;
	mso-header-margin:.5in;
	mso-footer-margin:.5in;}
.font0
	{color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Arial;
	mso-generic-font-family:auto;
	mso-font-charset:0;}
tr
	{mso-height-source:auto;}
col
	{mso-width-source:auto;}
br
	{mso-data-placement:same-cell;}
td
	{mso-style-parent:style0;
	padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Arial;
	mso-generic-font-family:auto;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:general;
	vertical-align:bottom;
	border:none;
	mso-background-source:auto;
	mso-pattern:auto;
	mso-protection:locked visible;
	white-space:nowrap;
	mso-rotate:0;}
.xl24
	{mso-style-parent:style0;
	white-space:normal;}
.xl25
	{mso-style-parent:style0;
	font-weight:700;}
.xl26
	{mso-style-parent:style0;
	font-weight:700;
	text-align:right;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	background:white;
	mso-pattern:auto none;
	white-space:normal;}
.xl27
	{mso-style-parent:style0;
	font-weight:700;
	text-align:right;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	background:white;
	mso-pattern:auto none;
	white-space:normal;}
.xl28
	{mso-style-parent:style0;
	font-weight:700;
	text-align:right;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	background:white;
	mso-pattern:auto none;
	white-space:normal;}
.xl29
	{mso-style-parent:style0;
	color:gray;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	white-space:normal;}
.xl30
	{mso-style-parent:style0;
	font-weight:700;
	text-align:center;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	background:silver;
	mso-pattern:auto none;
	white-space:normal;}
.xl31
	{mso-style-parent:style0;
	font-weight:700;
	text-align:center;
	border:.5pt solid windowtext;
	background:silver;
	mso-pattern:auto none;
	white-space:normal;}
.xl32
	{mso-style-parent:style0;
	font-weight:700;
	text-align:center;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	background:silver;
	mso-pattern:auto none;
	white-space:normal;}
.xl33
	{mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	white-space:normal;}
.xl34
	{mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \\\\2\\-\\\\2??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	white-space:normal;}
.xl35
	{mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \\\\2\\-\\\\2??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	white-space:normal;}
.xl36
	{mso-style-parent:style0;
	color:#333333;
	font-size:14.0pt;
	font-weight:700;
	text-align:center;
	white-space:normal;}
.xl37
	{mso-style-parent:style0;
	color:gray;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	white-space:normal;}
.xl38
	{mso-style-parent:style0;
	color:gray;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid black;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	white-space:normal;}
.xl361 {mso-style-parent:style0;
	color:#333333;
	font-size:14.0pt;
	font-weight:700;
	text-align:center;
	white-space:normal;}
.xl3611 {mso-style-parent:style0;
	color:#333333;
	font-size:14.0pt;
	font-weight:700;
	text-align:center;
	white-space:normal;}
.xl362 {mso-style-parent:style0;
	color:#333333;
	font-size:14.0pt;
	font-weight:700;
	text-align:center;
	white-space:normal;}
.xl3621 {mso-style-parent:style0;
	color:#333333;
	font-size:14.0pt;
	font-weight:700;
	text-align:center;
	white-space:normal;}
.style2 {mso-style-parent: style0; color: #333333; font-size: 10pt; font-weight: 700; text-align: center; white-space: normal; }
.xl351 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \\\\2\\-\\\\2??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	white-space:normal;}
.xl331 {mso-style-parent:style0;
	color:red;
	font-size:13.5pt;
	font-weight:700;
	text-align:center;
	white-space:normal;}
-->
</style>
<!--[if gte mso 9]><xml>
 <x:ExcelWorkbook>
  <x:ExcelWorksheets>
   <x:ExcelWorksheet>
    <x:Name>Brands</x:Name>
    <x:WorksheetOptions>
     <x:Print>
      <x:ValidPrinterInfo/>
      <x:HorizontalResolution>300</x:HorizontalResolution>
      <x:VerticalResolution>300</x:VerticalResolution>
     </x:Print>
     <x:CodeName>Sheet1</x:CodeName>
     <x:Selected/>
     <x:Panes>
      <x:Pane>
       <x:Number>3</x:Number>
       <x:ActiveRow>14</x:ActiveRow>
       <x:ActiveCol>5</x:ActiveCol>
      </x:Pane>
     </x:Panes>
     <x:ProtectContents>False</x:ProtectContents>
     <x:ProtectObjects>False</x:ProtectObjects>
     <x:ProtectScenarios>False</x:ProtectScenarios>
    </x:WorksheetOptions>
   </x:ExcelWorksheet>
  </x:ExcelWorksheets>
  <x:WindowHeight>10005</x:WindowHeight>
  <x:WindowWidth>10005</x:WindowWidth>
  <x:WindowTopX>120</x:WindowTopX>
  <x:WindowTopY>135</x:WindowTopY>
  <x:ProtectStructure>False</x:ProtectStructure>
  <x:ProtectWindows>False</x:ProtectWindows>
 </x:ExcelWorkbook>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="1028"/>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1"/>
 </o:shapelayout></xml><![endif]-->
</head>

				

<body link=blue vlink=purple>

<table x:str border=0 cellpadding=0 cellspacing=0 width=1366 style='border-collapse:
 collapse;table-layout:fixed;width:483pt'>
 <col width=75 style='mso-width-source:userset;mso-width-alt:2742;width:56pt'>
 <col width=92 style='mso-width-source:userset;mso-width-alt:3364;width:69pt'>
 <col width=234 style='mso-width-source:userset;mso-width-alt:8557;width:176pt'>
 <col width=145 style='mso-width-source:userset;mso-width-alt:5302;width:109pt'>
 <col width=97 style='mso-width-source:userset;mso-width-alt:3547;width:73pt'>
 <tr height=28 style='mso-height-source:userset;height:21.0pt'>
   <td height=28 class=xl24 style='height:21.0pt'></td>
   <td colspan=5 class=xl36 style='width:354pt'><span class="xl331" style="width:475pt">INTERNAL USE ONLY</span></td>
   <td class=xl24></td>
   <td class=xl24></td>
   <td class=xl24></td>
   <td class=xl24></td>
   <td class=xl24></td>
 </tr>
 <tr height=28 style='mso-height-source:userset;height:21.0pt'>
   <td height=28 class=xl24 style='height:21.0pt'></td>
   <td colspan=5 class=xl36 style='width:354pt'>APDM Report</td>
   <td class=xl24></td>
   <td class=xl24></td>
   <td class=xl24></td>
   <td class=xl24></td>
   <td class=xl24></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl24 width=546 style='height:12.75pt;width:56pt'><!--[if gte vml 1]><v:shapetype
   id="_x0000_t201" coordsize="21600,21600" o:spt="201" path="m,l,21600r21600,l21600,xe">
   <v:stroke joinstyle="miter"/>
   <v:path shadowok="f" o:extrusionok="f" strokeok="f" fillok="f"
    o:connecttype="rect"/>
   <o:lock v:ext="edit" shapetype="t"/>
  </v:shapetype><v:shape id="_x0000_s1026" type="#_x0000_t201" style='position:absolute;
   margin-left:0;margin-top:0;width:1in;height:18pt;z-index:2;visibility:hidden'
   strokecolor="windowText [64]" o:insetmode="auto">
   <![if gte mso 9]><v:imagedata src="brand_files/image001.emz" o:title=""/>
   <![endif]><x:ClientData ObjectType="Pict">
    <x:SizeWithCells/>
    <x:CF>Pict</x:CF>
   </x:ClientData>
  </v:shape><v:shape id="_x0000_s1027" type="#_x0000_t201" style='position:absolute;
   margin-left:56.25pt;margin-top:0;width:1in;height:18pt;z-index:3;
   visibility:hidden' strokecolor="windowText [64]" o:insetmode="auto">
   <![if gte mso 9]><v:imagedata src="brand_files/image002.emz" o:title=""/>
   <![endif]><x:ClientData ObjectType="Pict">
    <x:SizeWithCells/>
    <x:CF>Pict</x:CF>
   </x:ClientData>
  </v:shape><![endif]--><![if !vml]><span style='mso-ignore:vglayout;
  position:absolute;z-index:2;margin-left:0px;margin-top:0px;width:96px;
  height:24px'><![endif]><![if !mso]>
  <div style="visibility:hidden"><![endif]><INPUT TYPE="hidden" VALUE="99fd708a-b82f-69c8-8146-492500fec8b1"
  v:shapes="_x0000_s1026" class=shape><![if !mso]></div>
  <![endif]><![if !vml]></span><span style='mso-ignore:vglayout;position:absolute;
  z-index:3;margin-left:75px;margin-top:0px;width:96px;height:24px'><![endif]><![if !mso]>
  <div style="visibility:hidden"><![endif]><INPUT TYPE="hidden" VALUE="aec6c707-fd03-2e3d-ae2e-489ab43566a3"
  v:shapes="_x0000_s1027" class=shape><![if !mso]></div>
  <![endif]><![if !vml]></span><![endif]></td>
  <td colspan=10 class=xl24 style='mso-ignore:colspan'></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 colspan=11 class=xl24 style='height:12.75pt;mso-ignore:colspan'></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 style='height:12.75pt'></td>
  <td width=546 align="right" class="xl25" style='width:69pt'><div align="right">Name  of report:</div></td>
  <td colspan="2"><strong>MFR/SUPPLIER/VENDOR MANAGEMENT</strong></td>
  <td width=546 >&nbsp;</td>
  <td width=546 >&nbsp;</td>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 style='height:12.75pt'></td>
  <td width=546 align="right" class="xl25" style='width:69pt'><div align="right">Description:</div></td>
  <td  width=0 >&nbsp;</td>
  <td  width=546 >&nbsp;</td>
  <td  width=546 >&nbsp;</td>
  <td  width=546 >&nbsp;</td>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 style='height:12.75pt'></td>
  <td width=546 align="right" class="xl25" style='width:69pt'><div align="right">UserName</div></td>
  <td  width=0 ><?php echo $user_name;?></td>
  <td  width=546 >&nbsp;</td>
  <td  width=546 >&nbsp;</td>
  <td  width=546 >&nbsp;</td>
  <td class=xl24></td>
  <td class=xl24></td>
  <td class=xl24></td>
  <td class=xl24></td>
  <td class=xl24></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
 	<td height=17 style='height:12.75pt'></td>
 	<td align="right" class="xl25" style='width:69pt'>Date:</td>
 	<td style='width:176pt'><?php echo $date?></td>
 	<td style='width:109pt'>&nbsp;</td>
 	<td style='width:109pt'>&nbsp;</td>
 	<td style='width:109pt'>&nbsp;</td>
 	<td class=xl24></td>
 	<td class=xl24></td>
 	<td class=xl24></td>
 	<td class=xl24></td>
 	<td class=xl24></td>
  </tr>
 <tr height=17 style='height:12.75pt'>
 	<td height=17 style='height:12.75pt'></td>
 	<td align="right" class="xl25" style='width:69pt'><div align="right"></div></td>
 	<td style='width:176pt'>&nbsp;</td>
 	<td style='width:109pt'>&nbsp;</td>
 	<td style='width:109pt'>&nbsp;</td>
 	<td style='width:109pt'>&nbsp;</td>
 	<td class=xl24></td>
 	<td class=xl24></td>
 	<td class=xl24></td>
 	<td class=xl24></td>
 	<td class=xl24></td>
  </tr>

 <tr height=17 style='height:12.75pt'>
  <td height=17 style='height:12.75pt'></td>
  <td width=546 align="right" class="xl25" style='width:69pt'>&nbsp;</td>
  <td width=546 style='width:176pt'>&nbsp;</td>
  <td width=546 style='width:109pt'>&nbsp;</td>
  <td width=546 style='width:109pt'>&nbsp;</td>
  <td width=546 style='width:109pt'>&nbsp;</td>
  <td class=xl24></td>
  <td class=xl24></td>
  <td class=xl24></td>
  <td class=xl24></td>
  <td class=xl24></td>
 </tr>

 <tr height=17 style='height:12.75pt'>
  <td height=17 style='height:12.75pt'></td>
  <td width=546 align="right" class="xl25" style='width:69pt'>&nbsp;</td>
  <td width=546 style='width:176pt'>&nbsp;</td>
  <td width=546 style='width:109pt'>&nbsp;</td>
  <td width=546 style='width:109pt'>&nbsp;</td>
  <td width=546 style='width:109pt'>&nbsp;</td>
  <td class=xl24></td>
  <td class=xl24></td>
  <td class=xl24></td>
  <td class=xl24></td>
  <td class=xl24></td>
 </tr>

 <tr height=17 style='height:12.75pt'>
  <td height=17 colspan=11 class=xl24 style='height:12.75pt;mso-ignore:colspan'></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 style='height:12.75pt'></td>
  <td class=xl25>Total:<font class="font0"> <?php echo $total?></font></td>
  <td colspan=9 style='mso-ignore:colspan'></td>
 </tr>
 <tr height=19 style='mso-height-source:userset;height:14.25pt'>
  <td height=19 style='height:14.25pt'></td>
  <td class=xl30 width=546 style='width:69pt'>Item</td>
  <td class=xl30 width=546 style='width:176pt'>Name</td>
  <td class=xl31 width=546 style='width:109pt'>Type</td>
  <td class=xl31 width=546 style='width:109pt'>Description</td>
  <td class=xl31 width=546 style='width:109pt'>Address </td>
  <td class=xl32 width=546 style='width:73pt'>Tel/Fax</td>
  <td class=xl32 width=546 style='width:73pt'>WebSite</td>
  <td class=xl32 width=546 style='width:73pt'>Contact Person </td>
  <td class=xl32 width=546 style='width:73pt'>Email</td>
  <td class=xl32 width=546 style='width:73pt'>Status</td>
 </tr>
 <?php  //for content  
 $i=1;  
 foreach($rows as $row){  
 $type = "";
 if( $row->info_type ==2){ $type='Vendor';}
 if( $row->info_type ==3){ $type='Supplier';}
 if( $row->info_type ==4){ $type='Manufacture';}
 
 ?>
 <tr height=34 style='height:25.5pt'>
  <td height=34 style='height:25.5pt'></td>
  <td class=xl33 width=546 style='width:69pt'><?php echo $i?>&nbsp;</td>
  <td class=xl33 width=546 style='width:176pt'><?php echo $row->info_name?></td>
  <td class=xl34 width=546 style='width:109pt' x:str="<?php echo $type?>"><?php echo $type?></td>
  <td class=xl34 width=546 style='width:109pt' x:str="<?php echo $row->info_description;?>"><?php echo $row->info_description;?></td>
  <td class=xl34 width=546 style='width:109pt' x:str="<?php echo $row->info_address?>"><?php echo $row->info_address?></td>
  <td class=xl35 width=546 style='width:73pt' x:str="<?php echo $row->info_telfax;?>"><span class="xl351" style="width:73pt">
  	<?php echo $row->info_telfax;?>
  </span></td>
  <td class=xl35 width=546 style='width:73pt' x:str="<?php echo $row->info_website?>"><?php echo $row->info_website?>></td>
  <td class=xl35 width=546 style='width:73pt' x:str="<?php echo $row->info_contactperson?>"><?php echo $row->info_contactperson?></td>
  <td class=xl35 width=546 style='width:73pt' x:str="<?php echo $row->info_email?>"><?php echo $row->info_email?></td>
  <td class=xl35 width=546 style='width:73pt' x:str="<?php echo ($row->info_activate) ? 'Inactivate' : 'Activate';?>"><?php echo ($row->info_activate) ? 'Inactivate' : 'Activate';?></td>
 </tr>
 <![if supportMisalignedColumns]>
 <tr height=0 style='display:none'>
  <td width=546 style='width:56pt'></td>
  <td width=546 style='width:69pt'></td>
  <td width=546 style='width:176pt'></td>
  <td width=546 style='width:109pt'></td>
  <td width=546 style='width:109pt'></td>
  <td width=546 style='width:109pt'></td>
  <td width=546 style='width:73pt'></td>
  <td width=546 style='width:73pt'></td>
  <td width=546 style='width:73pt'></td>
  <td width=546 style='width:73pt'></td>
  <td width=546 style='width:73pt'></td>
 </tr>
 <![endif]>
 <?php 
 // end content    
 $i++;   } ?>
</table>

</body>

</html>
