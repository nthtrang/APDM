<?php defined('_JEXEC') or die('Restricted access'); ?>

<?php JHTML::_('behavior.tooltip'); ?>

<?php
	$role = JAdministrator::RoleOnComponent(5);
        $cid = JRequest::getVar( 'cid', array(0) );
	$tabfiles = '<button onclick="javascript:hideMainMenu(); submitbutton(\'files\')" class="buttonfiles" style="vertical-align:middle"><span>Files </span></button>';
        $tabsummary = '<button onclick="javascript:hideMainMenu(); submitbutton(\'summary\')" class="buttonfiles" style="vertical-align:middle"><span>Summary </span></button>';        
	JToolBarHelper::title( JText::_( 'ADP ECO MAMANGEMENT' )  . ': <small><small>[ '. JText::_( 'Affected Parts Edit' ).' ]</small></small>'.$tabfiles.$tabsummary, 'cpanel.png' );
	
		
	JToolBarHelper::cancel( 'cancel_listpns', 'Close' );
	if (in_array("W", $role)) {
		JToolBarHelper::addPns("New",$cid[0]);
	} 
        
//	if (in_array("E", $role)) {
//		JToolBarHelper::editListX();
//	}
	if (in_array("D", $role)) {
		JToolBarHelper::deletePns('Are you sure to delete it?');
	}
	
	$cparams = JComponentHelper::getParams ('com_media');
?>

<?php
	// clean item data
	JFilterOutput::objectHTMLSafe( $user, ENT_QUOTES, '' );

	
?>
<script language="javascript">
function submitbutton(pressbutton) {
			var form = document.adminForm;
                        if (pressbutton == 'summary') {
                                window.location.assign("index.php?option=com_apdmeco&task=detail&cid[]=<?php echo $cid[0]?>")
                                return;
                        }
                        if (pressbutton == 'files') {
                                window.location.assign("index.php?option=com_apdmeco&task=files&cid[]=<?php echo $cid[0]?>");
                                return;
                        }                           
			if (pressbutton == 'cancel_listpns') {				
				submitform( pressbutton );
				return;
			}
                        if (pressbutton == 'cancel_listpns') {				
				submitform( pressbutton );
				return;
			}
			if (pressbutton == 'export_bom') {				
				submitform( pressbutton );
				return;
			}
                        if(pressbutton == 'removepns')
                        {
                             submitform( pressbutton );
                             return;
                        }
}

</script>
<style>
        .buttonfiles {
  display: inline-block;
  border-radius: 4px;
  background-color: #f49542;
  border: none;
  color: white;
  text-align: center;
  font-size: 16px;
  padding: 10px 32px;
  width: 120px;
  transition: all 0.5s;
  cursor: pointer;
  margin-left: 30px;
}

.buttonaffected {
  display: inline-block;
  border-radius: 4px;
  background-color: #f49542;
  border: none;
  color: white;
  text-align: center;
  font-size: 16px;
  padding: 10px 32px;
  width: 180px;
  transition: all 0.5s;
  cursor: pointer;
  margin-left: 30px;
}
</style>
<form action="index.php?option=com_apdmpns" method="post" name="adminForm" onsubmit="submitbutton('')" >
<table class="adminlist" cellpadding="1">
		<thead>
			<tr>
				<th width="2%" class="title">
					<?php echo JText::_( 'NUM' ); ?>
				</th>
				<th width="3%" class="title">
					<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->rows); ?>);" />
				</th>
				<th class="title" width="15%">
					<?php echo  JText::_('PART_NUMBER_CODE'); ?>
                                </th>
				<th  class="title" width="10%">
					<?php echo  JText::_('PNS_DESCRIPTION'); ?>
				</th>
				
				<th width="5%" class="title" nowrap="nowrap">
					<?php echo JText::_('Status'); ?>
				</th>
				<th width="5%" class="title" nowrap="nowrap">
					<?php echo JText::_('Type'); ?>
				</th>
                                <th class="title"  >
					<?php echo JText::_( 'Vendor' ); ?>
				</th>
                                <th class="title"  >
					<?php echo JText::_( 'Vendor_PN' ); ?>
				</th>                                
				<th class="title"  >
					<?php echo JText::_( 'Supplier' ); ?>
				</th>
				<th class="title"  >
					<?php echo JText::_( 'Supplier_PN' ); ?>
				</th>				
				<th width="20%" class="title">
					<?php echo JText::_( 'PNS_MANUAFACTURE' ); ?>
				</th>
				<th class="title">
					<?php echo JText::_( 'Action' ); ?>
				</th>                                
			</tr>
		</thead>
		
		<tbody>
		<?php
			$path_image = '../uploads/pns/images/';
			$k = 0;
                        
			for ($i=0, $n=count( $this->rows ); $i < $n; $i++)
			{
       
				$row 	=& $this->rows[$i];
				$link 	= 'index.php?option=com_apdmpns&amp;task=detail&cid[0]='.$row->pns_id;	
                                $edit_link = 'index.php?option=com_apdmpns&amp;task=edit&cid[0]='.$row->pns_id;	
				$pns_code = $row->ccs_code.'-'.$row->pns_code.'-'.$row->pns_revision;
				if ($row->pns_image !=''){
					$pns_image = $path_image.$row->pns_image;
				}else{
					$pns_image = JText::_('NONE_IMAGE_PNS');
				}
				//echo $pns_image;
				$mf = EcoController::GetPnManufacture($row->pns_id);
				$mv = EcoController::GetPnVendor($row->pns_id);
                                $ms = EcoController::GetPnSupplier($row->pns_id);
			?>
			<tr class="<?php echo "row$k"; ?>">
				<td>
					<?php echo $i+1;?>
				</td>
				<td>
					<?php echo JHTML::_('grid.id', $i, $row->pns_id ); ?>
				</td>
				<td><span class="editlinktip hasTip" title="<img border=&quot;1&quot; src=&quot;<?php echo $pns_image; ?>&quot; name=&quot;imagelib&quot; alt=&quot;<?php echo JText::_( 'No preview available' ); ?>&quot; width=&quot;100&quot; height=&quot;100&quot; />" >
					<a href="<?php echo $link;?>" title="<?php echo JText::_('Click to see detail PNs');?>"><?php echo $pns_code;?></a>
				</span>
				</td>	
				
				<td align="center">
					<?php echo $row->pns_description; ?>
				</td>
				<td align="center">
					<?php echo $row->pns_status; ?>
				</td>				
				<td align="center">
					<?php echo $row->pns_type;?>
				</td>
				<td align="center">
					<?php 
					if (count($mv) > 0){
                                                foreach ($mv as $m){
                                                        echo $m['vendor_name'];
                                                }
					}
					 ?>
				</td>
				<td align="center">
					<?php 
					if (count($mv) > 0){
                                                foreach ($mv as $m){
                                                        echo $m['vendor_info'];
                                                }
					}
					 ?>
				</td>   
				<td align="center">
					<?php 
					if (count($ms) > 0){
                                                foreach ($ms as $m){
                                                        echo $m['supplier_name'];
                                                }
					}
					 ?>
				</td>
				<td align="center">
					<?php 
					if (count($ms) > 0){
                                                foreach ($ms as $m){
                                                        echo $m['supplier_info'];
                                                }
					}
					 ?>
				</td>                                
				<td>
					<?php 
					if (count($mf) > 0){
					foreach ($mf as $m){
						echo '<strong>-'.$m['mf'].': </strong>&nbsp;&nbsp;'.$m['v_mf'].'<br />';
					}
						
					}else{
						
					}
					 ?>
				</td>
				<td>
					<?php 
if ($row->pns_life_cycle =='Create') {
		?>
                  <a href="<?php echo $edit_link;?>" class="toolbar">
<span class="icon-32-edit" title="Edit">
</span>
Edit
</a>
                                        <?php 
		
	}
					 ?>
				</td>                                
			</tr>
			<?php
				$k = 1 - $k;
				}
			?>
		</tbody>
	</table>

	<div class="clr"></div>	
	<input type="hidden" name="option" value="com_apdmpns" />
	<input type="hidden" name="task" value="" />
        <input type="hidden" name="eco" value="<?php echo $cid[0]?>" />
	<input type="hidden" name="boxchecked" value="0" />
	<?php echo JHTML::_( 'form.token' ); ?>
</form>



